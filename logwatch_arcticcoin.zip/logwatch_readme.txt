This shell script needs to run in the background and is continuosly monitoring the arcticcoin logfile.
You can run it in a "screen" session (sudo apt-get install screen)
Before you run it, you must adjust some directories to your environment.
You will see which ones when you open the script, they are printed in CAPS. PATH-TO-ARCTICCOIN-DATA-DIRECTORY & PATH-TO-ARCTICCOIN-EXECUTABLES
change the script to make it executable: chmod +x logwatch_arcticcoin
Just let it run, and when a bad block appears it will do a masternode reset and reconsider the bad block,
so you don't have to reindex the blockchain.

If you like my efforts and think the script is usefull to you, a donation would be nice:

Arcticcoin: AHzbs6oFvWmpbHCwRhEHK7WkrXBNt5wp2r
Bitcoin: 18EmbsmuZPfur8uS2hNirx47gWc26yAQS2
Eth: 0x9f322ea2f4dd8bbc1e02a7879e74fb01914192c6 

Good luck,
Richard